YouTube Transcribe Downloader — offline pack
=============================================

Use this when the website cannot get a video's captions.
It works on your own computer, for any video, even with no captions.

WHAT YOU NEED
- A Windows computer.
- Internet, the first time only (to install what it needs).

HOW TO USE
1. Unzip this pack into a folder, for example on your Desktop.
2. Double-click run_transcript_v2.bat
   First time only: it installs Python if needed, then installs the
   tools. This takes a few minutes. If the video has no captions, it
   also downloads the voice model once (about 800 MB).
3. Paste a YouTube link and press Enter.
   Type the language code if you know it (hi, en, es, ja...) or just
   press Enter and it will work it out.
4. It tries the video's captions first (seconds). If there are none,
   it downloads the sound and writes down the words it hears.
   The two text files open in Notepad. They are saved in the
   transcripts folder.

FILES IN THIS PACK
- run_transcript_v2.bat — double-click this to start.
- yt_transcript_v2.py — the program that does the work.
- requirements.txt — the list of tools it installs.
- OFFLINE-README.txt — this file.

Please note: the words are heard by a computer, so a sung word can
sometimes be misheard. Captions from the video are exact when the
uploader provided them.
