UNIVERSAL TRANSCRIPTION STUDIO — COMPUTER PACKAGE
1. Extract all files into a folder.
2. Install Python 3.12 if not already installed.
3. On Windows double-click Open_Transcriber.bat. On macOS/Linux run sh start_studio.sh.
4. The local browser page opens after setup. Choose an authorized file or YouTube URL, leave Advanced selected, and click Transcribe & verify.
5. Local Whisper needs an initial model download. For optional independent cloud recognition enter your own key under Recognition engines & privacy. For optional vocal separation and acoustic alignment install maximum models (Install_Maximum_Models.bat on Windows).
6. Review uncertainties, listen to words, and save TXT, SRT or audit JSON.
Read STUDIO-README.md for privacy, limits, optional dependencies and troubleshooting. No AI guarantees perfect results.
